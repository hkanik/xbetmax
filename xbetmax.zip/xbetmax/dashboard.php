<?php
session_start();
$uname = $_SESSION['uname'];
?>
<!doctype html>
<html lang="`">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>xBetMax - Dashboard</title>
    <link rel="icon" href="images/fav.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/9d9350c87a.js"></script>
    <script language="JavaScript" type="text/javascript">
        window.history.forward();
    </script>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div class="top_header col-12 col-sm-12">
            <div class="top_header_menu col-12 col-sm-5 offset-sm-7">
                <div class="dropdown currency">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Main Account (BDT) 0
                    </button>

                    <div class="dropdown-menu currency_menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#">Other Currenciess (USD) 0</a>
                        <a class="dropdown-item" href="#">Other Currenciess (EUR) 0</a>
                    </div>
                </div>
                <div class="deposit">
                    <button class="btn btn-secondary" type="button">
                        <i class="fas fa-download"></i> Deposit
                    </button>
                </div>
                <div class="notification">
                    <button class="btn btn-secondary" type="button">
                        <i class="fas fa-envelope"></i>
                    </button>
                </div>

                <div class="dropdown main_acc">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo $uname ?>
                    </button>

                    <div class="dropdown-menu main_acc_menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#"><i class="fas fa-upload"></i> DEPOSIT</a>
                        <a class="dropdown-item" href="#"><i class="fas fa-upload"></i> WITHDRAW FUNDS</a>
                        <a class="dropdown-item" href="#"><i class="far fa-handshake"></i> AFFILIATE PROGRAM</a>
                        <a class="dropdown-item" href="#"><i class="fas fa-user-plus"></i> PERSONAL PROFILE</a>
                        <a class="dropdown-item" href="#"><i class="fas fa-history"></i> BET HSITORY</a>
                        <a class="dropdown-item" href="#"><i class="fas fa-cogs"></i> ACCOUNT SETTINGS</a>
                        <a class="dropdown-item" href="index.php"><i class="fas fa-sign-out-alt"></i> LOGOUT</a>

                    </div>
                </div>



            </div>
        </div>
    </div>

    <div class="row">
        <div class="header col-12">
            <div class="logo col-12 col-sm-3">
                <a href="index.php"><img src="images/logo.png" alt="logo"></a>
            </div>

            <div class="navbar col-12 col-sm-6">
                <ul>
                    <li class="active"><a href="index.php">HOME</a></li>
                    <li><a href="in_play.php">IN-PLAY</a></li>
                    <li><a href="prematch.php">PREMATCH</a></li>
                    <li><a href="game.php">GAME</a></li>
                    <li><a href="live_game.php">LIVE GAME</a></li>
                    <li><a href="promotion.php">PROMOTION</a></li>
                </ul>
            </div>

            <div class="login col-12 col-sm-3">


                <img src="images/usflag.png" alt="USA Flag">
            </div>
        </div>
    </div>

    <div class="row">
        <div class="sub_navbar col-12 col-sm-12">
            <div class="search col-12 col-sm-3">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Search">
            </div>

            <div class="sub_nav_element col-12 col-sm-9">
                <ul>
                    <li><a href="#">Responsible Gaming</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Pirvacy Policy</a></li>
                    <li><a href="#">FAQ</a></li>
                    <span id="MyClockDisplay" class="clock" onload="showTime()"></span>
                </ul>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="home_bar col-2 col-sm-2">
            <ul>
                <li><a href="#">Home</a></li>
            </ul>
        </div>

        <!--            for mobile-->
        <div class="home_bar_mob col-2 col-sm-2">
            <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample" id="navbtn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="home_bar_solid col-10 col-sm-10"></div>
    </div>
    <div class="row">
        <div class="sidebar col-2 col-sm-2">
            <ul>
                <li><a href="#">Live <span id="inplay">In Play</span></a></li>
                <li><a href="#">Crcket</a></li>
                <li><a href="#">Football</a></li>
                <li><a href="#">Basketball</a></li>
                <li><a href="#">Volleyball</a></li>
                <li><a href="#">Baseball</a></li>
                <li><a href="#">Ice Hockey</a></li>
                <li><a href="#">Handball</a></li>
                <li><a href="#">Table Tennis</a></li>
                <li><a href="#">American Football</a></li>
                <li><a href="#">Badminton</a></li>
                <li><a href="#">Snooker</a></li>
                <li><a href="#">Bandy</a></li>
                <li><a href="#">Field Hockey</a></li>
                <li><a href="#">Fustal</a></li>
                <li><a href="#">Boxing</a></li>
                <li><a href="#">Cycling</a></li>
                <li><a href="#">Rugby League</a></li>
                <li><a href="#">Rugby Union</a></li>
                <li><a href="#">Floorball</a></li>
                <li><a href="#">Gaelic Floorball</a></li>
                <li><a href="#">Golf</a></li>
                <li><a href="#">Hurling</a></li>
                <li><a href="#">MMA</a></li>
                <li><a href="#">The Penalty Kicks</a></li>
                <li><a href="#">Virtual Football</a></li>
                <li><a href="#">Virtual Greyhounds</a></li>
                <li><a href="#">Virtual Horse Racing</a></li>
                <li><a href="#">Water Polo</a></li>
                <li><a href="#">Virtual Tennis</a></li>
                <li><a href="#">Special Bets</a></li>
                <li><a href="#">What? Where? When?</a></li>
                <li><a href="#">Auto Racing</a></li>
                <li><a href="#">Netball</a></li>
                <li><a href="#">Virtual Car Racing</a></li>
                <li><a href="#">Tennis</a></li>
            </ul>
        </div>

        <!--            for mobile-->
        <div class="collapse sidebar_mob col-9 col-sm-2" id="collapseExample">
            <div class="card card-body sidebar_mob_body">

                <a class="dropdown-item dmenu" href="#">Home</a>
                <a class="dropdown-item dmenu" href="#">Live <span id="inplay">In Play</span></a>
                <a class="dropdown-item dmenu" href="#">Crcket</a>
                <a class="dropdown-item dmenu" href="#">Football</a>
                <a class="dropdown-item dmenu" href="#">Basketball</a>
                <a class="dropdown-item dmenu" href="#">Volleyball</a>
                <a class="dropdown-item dmenu" href="#">Baseball</a>
                <a class="dropdown-item dmenu" href="#">Ice Hockey</a>
                <a class="dropdown-item dmenu" href="#">Handball</a>
                <a class="dropdown-item dmenu" href="#">Table Tennis</a>
                <a class="dropdown-item dmenu" href="#">American Football</a>
                <a class="dropdown-item dmenu" href="#">Badminton</a>
                <a class="dropdown-item dmenu" href="#">Snooker</a>
                <a class="dropdown-item dmenu" href="#">Bandy</a>
                <a class="dropdown-item dmenu" href="#">Field Hockey</a>
                <a class="dropdown-item dmenu" href="#">Fustal</a>
                <a class="dropdown-item dmenu" href="#">Boxing</a>
                <a class="dropdown-item dmenu" href="#">Cycling</a>
                <a class="dropdown-item dmenu" href="#">Rugby League</a>
                <a class="dropdown-item dmenu" href="#">Rugby Union</a>
                <a class="dropdown-item dmenu" href="#">Floorball</a>
                <a class="dropdown-item dmenu" href="#">Gaelic Floorball</a>
                <a class="dropdown-item dmenu" href="#">Golf</a>
                <a class="dropdown-item dmenu" href="#">Hurling</a>
                <a class="dropdown-item dmenu" href="#">MMA</a>
                <a class="dropdown-item dmenu" href="#">The Penalty Kicks</a>
                <a class="dropdown-item dmenu" href="#">Virtual Football</a>
                <a class="dropdown-item dmenu" href="#">Virtual Greyhounds</a>
                <a class="dropdown-item dmenu" href="#">Virtual Horse Racing</a>
                <a class="dropdown-item dmenu" href="#">Water Polo</a>
                <a class="dropdown-item dmenu" href="#">Virtual Tennis</a>
                <a class="dropdown-item dmenu" href="#">Special Bets</a>
                <a class="dropdown-item dmenu" href="#">What? Where? When?</a>
                <a class="dropdown-item dmenu" href="#">Auto Racing</a>
                <a class="dropdown-item dmenu" href="#">Netball</a>
                <a class="dropdown-item dmenu" href="#">Virtual Car Racing</a>
                <a class="dropdown-item dmenu" href="#">Tennis</a>

            </div>
        </div>

        <div class="main_content_wrapper col-12 col-sm-10">
                        <div class="main_content col-5">
                            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img src="images/289f20b54e866aa6b07002e7df0b1b67.jpg" class="d-block w-100" alt="...">
                                    </div>
                                    <div class="carousel-item">
                                        <img src="images/5abda25d1e75a7d182c7793ad95b1c3d.jpg" class="d-block w-100" alt="...">
                                    </div>
                                    <div class="carousel-item">
                                        <img src="images/986fe07a605f6d78c95e4dcb41bb4a77.jpg" class="d-block w-100" alt="...">
                                    </div>
                                </div>
                            </div>
                        </div>

            <!--            <div class="news col-4">-->
            <!--                <div class="highlight">-->
            <!--                    <h2 class="highlight_bar">Highlight</h2>-->
            <!--                        <p>Coming Soon...</p>-->
            <!--                </div>-->
            <!--                <div class="popular_event">-->
            <!--                    <h2 class="popular_event_bar">Popular Evnet</h2>-->
            <!--                        <p>Coming Soon...</p>-->
            <!--                </div>-->
            <!---->
            <!--            </div>-->
            <!---->
            <!--            <div class="right_sidebar col-3">-->
            <!--                <div class="betslip">-->
            <!--                    <h2 class="barsp">Betslip</h2>-->
            <!--                    <p>No bets have been selected. To select a bet, please click on the respective result.</p>-->
            <!--                </div>-->
            <!--                <div class="gaming">-->
            <!--                    <h2 class="bar">Gaming</h2>-->
            <!--                    <p>Coming Soon...</p>-->
            <!--                </div>-->
            <!--                <div class="promotion">-->
            <!--                    <h2 class="bar">promotion</h2>-->
            <!--                    <p>Coming Soon...</p>-->
            <!--                </div>-->
            <!--            </div>-->
            <h1 style="text-align: center">DASHBOARD SECTION</h1>
        </div>

    </div>

    <div class="row">
        <div class="footer col-12 col-sm-12">
            <div class="row">
                <div class="branding col-12 col-sm-4">
                    <img src="images/logo-foot.png" alt="Footer Logo">
                    <p>xBetMax is the International Trusted Playing Site.</p>
                </div>

                <div class="footer_about col-6 col-sm-3">
                    <p>About</p>
                    <ul>
                        <li><a href="#">About us</a></li>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">General Terms & Condition</a></li>
                        <li><a href="#">Responsible Gaming</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>

                <div class="newsletter col-6 col-sm-5">
                    <input type="text" placeholder="Email"><br>
                    <button type="submit">Subscribe</button>
                </div>
            </div>

            <div class="row">
                <div class="help col-6 col-sm-4">
                    <p>Help</p>
                    <ul>
                        <li><a href="#">FAQs</a></li>
                        <li><a href="#">Sports Playing</a></li>
                        <li><a href="#">Game</a></li>
                        <li><a href="#">Affiliates</a></li>
                    </ul>
                </div>

                <div class="products col-6 col-sm-4">
                    <p>Products</p>
                    <ul>
                        <li class="active"><a href="#" active>Home</a></li>
                        <li><a href="#">In-play</a></li>
                        <li><a href="#">Prematch</a></li>
                        <li><a href="#">Game</a></li>
                        <li><a href="#">Live Game</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>