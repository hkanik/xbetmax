<?php
if(!empty($_POST)){
    $mysqli = new mysqli('localhost', 'root', '','xBetMax');

    if($mysqli->connect_error){
        die('Connection Error'.$mysqli->connect_error.':'.$mysqli->connect_error);
    }

    $usrname = $_POST['user_name'];
    $usr = "SELECT * FROM user WHERE userName = '$usrname'";
    $res = mysqli_query($mysqli, $usr);
    $num = mysqli_num_rows($res);

    if ($num !=1){
        echo "
            <script type=\"text/javascript\">
                alert('User Name is Not Valid!!!');
            </script>
        ";
    }else {

        $pass = $_POST['pass'];
        $pass = md5($pass);
        $sql = "UPDATE user SET password = '$pass'  WHERE  userName = '$usrname' LIMIT 1";

        $insert = $mysqli->query($sql);
        if ($insert) {
            header('location: thanksp.php');
        } else {
            die("Error: {$mysqli->errno}: {$mysqli->error}");
        }
    }
    $mysqli->close();
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>xBetMax - Sports</title>
    <link rel="icon" href="images/fav.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/9d9350c87a.js"></script>
</head>
<body>
    <div class="col-sm-6">
        <h2 style="text-align: center;margin-top: 5%;margin-bottom: 5%;">To <span style="color: red;">Change Password</span> Fill Out These Information Properly</h2>
        <form action="" method="post" class="form-group" onsubmit="return validationp()">
            <input style="margin-bottom: 2%" required class="form-control" type="text" name="user_name" placeholder="*Enter Your User Name">
            <input style="margin-bottom: 2%" required class="form-control" id="pass" type="password" name="pass" placeholder="*Enter New Password">

            <span id="passs" style="color: red;"></span>
            <input style="margin-bottom: 2%" required class="form-control" id="confpass" type="password" name="con_pass" placeholder="*Enter Confirm Password">

            <span id="confpasss" style="color: red;"></span> <br>
            <input class="btn btn-primary" type="submit" name="submit">

        </form>
    </div>

    <script>
        function validationp() {
            var pass = document.getElementById('pass').value;
            var confpass = document.getElementById('confpass').value;

            if((pass.length <= 6)||(pass.length >20)){
                document.getElementById('passs').innerHTML = "* Enter a Password Between 6-20 digit!";
                return false;
            }

            if(pass != confpass){
                document.getElementById('confpasss').innerHTML = "* Password not matched!";
                return false;
            }

        }
    </script>



</body>
</html>
