<?php

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.sportradar.com/soccer/trial/v4/en/schedules/live/summaries.json?api_key=mtg59t29wswb3wmb3csx3aja",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET"
));

$response = curl_exec($curl);
$json = json_decode($response,true);
function display($json_rec)
{

    if ($json_rec) {
        foreach ($json_rec as $key => $value) {
            if (is_array($value)) {
                display($value);
            } else {
                echo '<span style="font-weight: bold;">' . $key . '</span>' . ' ' . '-' . ' ';
                echo '<span style="color: powderblue;">' . $value . '</span>' . '<br>';
            }
        }
        echo '<br>';
    }
}
?>