<?php
$curl = curl_init();

//curl_setopt_array($curl, array(
//    CURLOPT_URL => "https://api.sportradar.com/soccer/trial/v4/en/competitions/sr:competition:17/seasons.json?api_key=mtg59t29wswb3wmb3csx3aja",
//    CURLOPT_RETURNTRANSFER => true,
//    CURLOPT_ENCODING => "",
//    CURLOPT_MAXREDIRS => 10,
//    CURLOPT_TIMEOUT => 30,
//    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//    CURLOPT_CUSTOMREQUEST => "GET"
//));
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api-football-v1.p.rapidapi.com/v2/fixtures/league/4",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
        "x-rapidapi-host: api-football-v1.p.rapidapi.com",
        "x-rapidapi-key: fc683c7c7dmshca51b2fb7404fcdp1b5646jsnf4fa50945f8b"
    ),
));

$response = curl_exec($curl);
$json = json_decode($response,true);
function display($json_rec)
{

    if ($json_rec) {
        foreach ($json_rec as $key => $value) {
            if (is_array($value)) {
                display($value);
            } else {
                echo '<span style="font-weight: bold;">' . $key . '</span>' . ' ' . '-' . ' ';
                echo '<span style="color: powderblue;">' . $value . '</span>' . '<br>';
            }
        }
        echo '<br>';
    }
}
?>
