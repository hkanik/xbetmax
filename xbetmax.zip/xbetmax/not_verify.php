<?php
session_start();

$email = $_SESSION['email'];
$date = $_SESSION['date'];
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Not Verified</title>
    <link rel="icon" href="images/fav.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/9d9350c87a.js"></script>

</head>
<body style="text-align: center">

    <h3 style="line-height: 2">This Account Not Verified! code send to <br> Email: <?php echo $email?> <br> Date: <?php echo $date?></h3>
    <a class="btn btn-primary" href="index.php">Go To Login</a>
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>
