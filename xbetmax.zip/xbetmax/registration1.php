<?php

session_start();
if(!empty($_POST)){
    $mysqli = new mysqli('localhost', 'root', '','xBetMax');

    if($mysqli->connect_error){
        die('Connection Error'.$mysqli->connect_error.':'.$mysqli->connect_error);
    }

    $usrname = $_POST['user_name'];
    $usr = "SELECT * FROM user WHERE userName = '$usrname'";
    $res = mysqli_query($mysqli, $usr);
    $num = mysqli_num_rows($res);

    if ($num == 1){
        echo "
            <script type=\"text/javascript\">
                alert('User Name Already Exist!!!');
            </script>
        ";
    }else {
        $vkey = md5(time().$_POST['user_name']);
        $pass = $_POST['password'];
        $pass = md5($pass);
        $sql = "INSERT INTO user (firstname, surName, dob, gender, mobileNumber, userName, email, confEmail, password, confPassword, vkey) VALUES ('{$mysqli->real_escape_string($_POST['first_name'])}','{$mysqli->real_escape_string($_POST['sur_name'])}','{$mysqli->real_escape_string($_POST['dob'])}','{$mysqli->real_escape_string($_POST['gender'])}','{$mysqli->real_escape_string($_POST['mobile_number'])}','{$mysqli->real_escape_string($_POST['user_name'])}','{$mysqli->real_escape_string($_POST['email'])}','{$mysqli->real_escape_string($_POST['confirm_email'])}','{$mysqli->real_escape_string($pass)}','{$mysqli->real_escape_string($pass)}','{$mysqli->real_escape_string($vkey)}')";

        $insert = $mysqli->query($sql);
        if ($insert) {

            $to = $_POST['email'];
            $subject = "Email Verification";
            $message = "<a href='http://localhost/xbetmax/verify.php?vkey=$vkey'>Verify Account";
            $headers = "From: mdhumayunanik@gmail.com \r\n";
            $headers .= "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

            mail($to, $subject, $message, $headers);
//            $mail = new PHPMailer();
//            $mail->isSMTP();
//            $mail->SMTPAuth = true;
//            $mail->SMTPSecure = 'ssl';
//            $mail->Host = 'smtp.gmail.com';
//            $mail->Port = '465';
//            $mail->isHTML(true);
//            $mail->Username='mdhumayunanik@gmail.com';
//            $mail->Password = 'anik1436';
//            $mail->SetFrom('mdhumayunanik@gmail.com');
//            $mail->Subject='Email Verification';
//            $mail->Body="<a href='http://localhost/xbetmax/verify.php?vkey=$vkey'>Verify Accountwqw";
//            $mail->AddAddress($to);
//
//            $mail-> send();
            header('location: thanks.php');
        } else {
            die("Error: {$mysqli->errno}: {$mysqli->error}");
        }
    }
    $mysqli->close();
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>xBetMax - Registration</title>
    <link rel="icon" href="images/fav.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/9d9350c87a.js"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="registration col-5">
                <span>Fill Up The Registration Form</span>
            </div>
        </div>

        <div class="row">
            <div class="reg_form col-5">
                <form action="" method="post" onsubmit="return validation()">
                    <input type="text" name="first_name" id="fname" class="form_cont" required placeholder="Enter Your First Name"> <br>
                    <span id="fnames" style="color: red;"></span>
                    <input type="text" name="sur_name" id="surname" class="form_cont" required placeholder="Enter Your Sur Name"><br>
                    <span id="surnames" style="color: red;"></span>
                    <input type="text" name="dob" id="dob" required placeholder="DD/MM/YYYY" class="form_cont"><br>
                    <span id="dobs" style="color: red;"></span>
                    <input type="radio" name="gender" id="m" required class="gen" value="Male"><label>Male</label>
                    <input type="radio" name="gender" id="f" required class="gen" value="Female"><label>Female</label><br>
                    <span id="gens" style="color: red;"></span>
                    <input type="tel" name="mobile_number" id="mobnumber" required class="form_cont" placeholder="Enter Your Mobile Number"><br>
                    <span id="mobnumbers" style="color: red;"></span>
                    <input type="text" name="user_name" required id="userName" class="form_cont" placeholder="Enter A User Name"><br>
                    <span id="userNames" style="color: red;"></span>
                    <input type="email" name="email" required id="email" class="form_cont" placeholder="Enter Your Email Address"><br>
                    <span id="emails" style="color: red;"></span>
                    <input type="email" name="confirm_email" id="conemail" required class="form_cont" placeholder="Confirm Your Email Address"><br>
                    <span id="conemails" style="color: red;"></span>
                    <input type="password" name="password" id="pass" required class="form_cont" placeholder="Enter A Password"><br>
                    <span id="passs" style="color: red;"></span>
                    <input type="password" name="confirm_password" id="confpass" required class="form_cont" placeholder="Confirm The Password"><br>
                    <span id="confpasss" style="color: red;"></span> <br>
                    <input type="submit" name="submit" id="subbtn" class="reg_sub_btn" value="Register"><br>
                </form>
            </div>
        </div>
    </div>



    <script>
        function validation() {

            var fname = document.getElementById('fname').value;
            var surname = document.getElementById('surname').value;
            var dob = document.getElementById('dob').value;
            var m = document.getElementById('m').value;
            var f = document.getElementById('f').value;
            var mobnumber = document.getElementById('mobnumber').value;
            var userName = document.getElementById('userName').value;
            var email = document.getElementById('email').value;
            var conemail = document.getElementById('conemail').value;
            var pass = document.getElementById('pass').value;
            var confpass = document.getElementById('confpass').value;

            console.log(mobnumber);

            if((fname.length <= 2)||(fname.length >20)){
                document.getElementById('fnames').innerHTML = "* Enter a Valid Name";
                return false;
            }
            if(!isNaN(fname)){
                document.getElementById('fnames').innerHTML = "* Name Can't be a Number!";
                return false;
            }
            if((surname.length <= 2)||(surname.length >20)){
                document.getElementById('surnames').innerHTML = "** Enter a Valid Name";
                return false;
            }
            if(!isNaN(surname)){
                document.getElementById('surnames').innerHTML = "* Name Can't be a Number!";
                return false;
            }
            if(isNaN(mobnumber)){
                document.getElementById('mobnumbers').innerHTML = "* Mobile Number Can't be a Character!";
                return false;
            }
            if(mobnumber.length !=11 ){
                document.getElementById('mobnumbers').innerHTML = "* Enter 11 Digit Mobile Number!";
                return false;
            }
            if((userName.length <= 3)||(userName.length >20)){
                document.getElementById('userNames').innerHTML = "* Enter a User Name Between 3-20 digit!";
                return false;
            }
            if(email != conemail){
                document.getElementById('conemails').innerHTML = "* Email not matched!";
                return false;
            }
            if((pass.length <= 6)||(pass.length >20)){
                document.getElementById('passs').innerHTML = "* Enter a Password Between 6-20 digit!";
                return false;
            }

            if(pass != confpass){
                document.getElementById('confpasss').innerHTML = "* Password not matched!";
                return false;
            }

        }
    </script>

    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>
