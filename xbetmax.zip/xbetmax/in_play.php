<?php
require_once('api/competition.php');
?>
<!doctype html>
<html lang="`">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>xBetMax - In-Play</title>
    <link rel="icon" href="images/fav.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/9d9350c87a.js"></script>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div class="header col-12">
            <div class="logo col-12 col-sm-3">
                <a href="index.php"><img src="images/logo.png" alt="logo"></a>
            </div>

            <div class="navbar col-12 col-sm-6">
                <ul>
                    <li class="active"><a href="index.php">HOME</a></li>
                    <li><a href="in_play.php">IN-PLAY</a></li>
                    <li><a href="prematch.php">PREMATCH</a></li>
                    <li><a href="game.php">GAME</a></li>
                    <li><a href="live_game.php">LIVE GAME</a></li>
                    <li><a href="promotion.php">PROMOTION</a></li>
                </ul>
            </div>

            <div class="login col-12 col-sm-3">
                <ul>
                    <li><a href="registration.php">Registration</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#login" id="log">Login</a></li>
                </ul>

                <img src="images/usflag.png" alt="USA Flag">
            </div>
        </div>
    </div>

    <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="loginlabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="loginlabel">LOGIN TO YOUR ACCOUNT</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body form-group">
                    <form action="" method="post">
                        <input type="text" class="form-control" required id="user_name" name="user_name" placeholder="User Name"><br>
                        <input type="password" class="form-control" required id="user_password" name="password" placeholder="Password"><br>
                        <input type="submit" name="submit" value="LOGIN" class="btn btnl btn-primary">
                    </form>
                </div>
                <div class="modal-footer"></div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="sub_navbar col-12 col-sm-12">
            <div class="search col-12 col-sm-3">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Search">
            </div>

            <div class="sub_nav_element col-12 col-sm-9">
                <ul>
                    <li><a href="#">Responsible Gaming</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Pirvacy Policy</a></li>
                    <li><a href="#">FAQ</a></li>
                    <span id="MyClockDisplay" class="clock" onload="showTime()"></span>
                </ul>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="home_bar col-2 col-sm-2">
            <ul>
                <li><a href="#">Home</a></li>
            </ul>
        </div>

        <!--            for mobile-->
        <div class="home_bar_mob col-2 col-sm-2">
            <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample" id="navbtn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="home_bar_solid col-10 col-sm-10"></div>
    </div>

    <div class="row">
        <div class="sidebar col-2 col-sm-2">
            <ul>
                <li><a href="#">Live <span id="inplay">In Play</span></a></li>
                <li><a href="#">Crcket</a></li>
                <li><a href="#">Football</a></li>
                <li><a href="#">Basketball</a></li>
                <li><a href="#">Volleyball</a></li>
                <li><a href="#">Baseball</a></li>
                <li><a href="#">Ice Hockey</a></li>
                <li><a href="#">Handball</a></li>
                <li><a href="#">Table Tennis</a></li>
                <li><a href="#">American Football</a></li>
                <li><a href="#">Badminton</a></li>
                <li><a href="#">Snooker</a></li>
                <li><a href="#">Bandy</a></li>
                <li><a href="#">Field Hockey</a></li>
                <li><a href="#">Fustal</a></li>
                <li><a href="#">Boxing</a></li>
                <li><a href="#">Cycling</a></li>
                <li><a href="#">Rugby League</a></li>
                <li><a href="#">Rugby Union</a></li>
                <li><a href="#">Floorball</a></li>
                <li><a href="#">Gaelic Floorball</a></li>
                <li><a href="#">Golf</a></li>
                <li><a href="#">Hurling</a></li>
                <li><a href="#">MMA</a></li>
                <li><a href="#">The Penalty Kicks</a></li>
                <li><a href="#">Virtual Football</a></li>
                <li><a href="#">Virtual Greyhounds</a></li>
                <li><a href="#">Virtual Horse Racing</a></li>
                <li><a href="#">Water Polo</a></li>
                <li><a href="#">Virtual Tennis</a></li>
                <li><a href="#">Special Bets</a></li>
                <li><a href="#">What? Where? When?</a></li>
                <li><a href="#">Auto Racing</a></li>
                <li><a href="#">Netball</a></li>
                <li><a href="#">Virtual Car Racing</a></li>
                <li><a href="#">Tennis</a></li>
            </ul>
        </div>

        <!--            for mobile-->
        <div class="collapse sidebar_mob col-9 col-sm-2" id="collapseExample">
            <div class="card card-body sidebar_mob_body">

                <a class="dropdown-item dmenu" href="#">Home</a>
                <a class="dropdown-item dmenu" href="#">Live <span id="inplay">In Play</span></a>
                <a class="dropdown-item dmenu" href="#">Crcket</a>
                <a class="dropdown-item dmenu" href="#">Football</a>
                <a class="dropdown-item dmenu" href="#">Basketball</a>
                <a class="dropdown-item dmenu" href="#">Volleyball</a>
                <a class="dropdown-item dmenu" href="#">Baseball</a>
                <a class="dropdown-item dmenu" href="#">Ice Hockey</a>
                <a class="dropdown-item dmenu" href="#">Handball</a>
                <a class="dropdown-item dmenu" href="#">Table Tennis</a>
                <a class="dropdown-item dmenu" href="#">American Football</a>
                <a class="dropdown-item dmenu" href="#">Badminton</a>
                <a class="dropdown-item dmenu" href="#">Snooker</a>
                <a class="dropdown-item dmenu" href="#">Bandy</a>
                <a class="dropdown-item dmenu" href="#">Field Hockey</a>
                <a class="dropdown-item dmenu" href="#">Fustal</a>
                <a class="dropdown-item dmenu" href="#">Boxing</a>
                <a class="dropdown-item dmenu" href="#">Cycling</a>
                <a class="dropdown-item dmenu" href="#">Rugby League</a>
                <a class="dropdown-item dmenu" href="#">Rugby Union</a>
                <a class="dropdown-item dmenu" href="#">Floorball</a>
                <a class="dropdown-item dmenu" href="#">Gaelic Floorball</a>
                <a class="dropdown-item dmenu" href="#">Golf</a>
                <a class="dropdown-item dmenu" href="#">Hurling</a>
                <a class="dropdown-item dmenu" href="#">MMA</a>
                <a class="dropdown-item dmenu" href="#">The Penalty Kicks</a>
                <a class="dropdown-item dmenu" href="#">Virtual Football</a>
                <a class="dropdown-item dmenu" href="#">Virtual Greyhounds</a>
                <a class="dropdown-item dmenu" href="#">Virtual Horse Racing</a>
                <a class="dropdown-item dmenu" href="#">Water Polo</a>
                <a class="dropdown-item dmenu" href="#">Virtual Tennis</a>
                <a class="dropdown-item dmenu" href="#">Special Bets</a>
                <a class="dropdown-item dmenu" href="#">What? Where? When?</a>
                <a class="dropdown-item dmenu" href="#">Auto Racing</a>
                <a class="dropdown-item dmenu" href="#">Netball</a>
                <a class="dropdown-item dmenu" href="#">Virtual Car Racing</a>
                <a class="dropdown-item dmenu" href="#">Tennis</a>

            </div>
        </div>

        <div class="main_content_wrapper col-12 col-sm-10">
                        <div class="main_content col-5">
                            <div class="content-imgae">
                                    <h2 class="highlight_bar">Competition - Soccer</h2>
                                <table>
                                    <tr>
                                        <td style="color: white;"><?php display($json);?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <div class="news col-4">
                            <div class="highlight">
                                <h2 class="highlight_bar">Highlight</h2>
                                    <p></p>
                            </div>
                            <div class="popular_event">
                                <h2 class="popular_event_bar">Popular Evnet</h2>
                                    <p>Coming Soon...</p>
                            </div>

                        </div>

                        <div class="right_sidebar col-3">
                            <div class="betslip">
                                <h2 class="barsp">Betslip</h2>
                                <p>No bets have been selected. To select a bet, please click on the respective result.</p>
                            </div>
                            <div class="gaming">
                                <h2 class="bar">Gaming</h2>
                                <p>Coming Soon...</p>
                            </div>
                            <div class="promotion">
                                <h2 class="bar">promotion</h2>
                                <p>Coming Soon...</p>
                            </div>
                        </div>



        </div>

    </div>

    <div class="row">
        <div class="footer col-12 col-sm-12">
            <div class="row">
                <div class="branding col-12 col-sm-4">
                    <img src="images/logo-foot.png" alt="Footer Logo">
                    <p>xBetMax is the International Trusted Playing Site.</p>
                </div>

                <div class="footer_about col-6 col-sm-3">
                    <p>About</p>
                    <ul>
                        <li><a href="#">About us</a></li>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">General Terms & Condition</a></li>
                        <li><a href="#">Responsible Gaming</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>

                <div class="newsletter col-6 col-sm-5">
                    <input type="text" placeholder="Email"><br>
                    <button type="submit">Subscribe</button>
                </div>
            </div>

            <div class="row">
                <div class="help col-6 col-sm-4">
                    <p>Help</p>
                    <ul>
                        <li><a href="#">FAQs</a></li>
                        <li><a href="#">Sports Playing</a></li>
                        <li><a href="#">Game</a></li>
                        <li><a href="#">Affiliates</a></li>
                    </ul>
                </div>

                <div class="products col-6 col-sm-4">
                    <p>Products</p>
                    <ul>
                        <li class="active"><a href="#" active>Home</a></li>
                        <li><a href="#">In-play</a></li>
                        <li><a href="#">Prematch</a></li>
                        <li><a href="#">Game</a></li>
                        <li><a href="#">Live Game</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>
