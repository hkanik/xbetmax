<?php
    if (isset($_GET['vkey'])){

        $vkey = $_GET['vkey'];

        $mysqli = new mysqli('localhost', 'root', '','xBetMax');
        $result = $mysqli->query("SELECT vkey, vStatus FROM user WHERE vStatus = 0 AND vkey = '$vkey' LIMIT 1");
        if ($result->num_rows == 1){
            $update = $mysqli->query("UPDATE user SET vStatus = 1 WHERE vkey = '$vkey' LIMIT 1");
            if ($update){
                header('location: confirmation.php');
            }else{
                echo $mysqli->error;
            }
        }else{
            echo "Account is not verified";
        }
    }else{
        die("Something Went Wrong");
    }
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email Verification</title>
</head>
<body>

</body>
</html>
